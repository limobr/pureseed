import Link from "next/link";
import Image from "next/image";
import CTA from "@/components/CTA";
import { meta } from "@/lib/seo";
import { services } from "@/lib/data";

export const metadata = meta("Services & Capabilities", "Agricultural sourcing, bulk supply, processing, quality and traceability, packaging, private label and export logistics from one integrated supply chain.", "/our-services");

export default function Services() {
  return (
    <>
      <section className="page-hero"><div className="wrap"><h1>Services and capabilities</h1><p className="lead">Responsible sourcing, modern processing, quality control and export capabilities.</p></div></section>
      <section className="sec"><div className="wrap sgrid">
        {services.map((s) => (
          <Link key={s.slug} href={`/service/${s.slug}`} className="scard">
            <Image src={s.image} alt={s.headline} width={576} height={400} sizes="(max-width:700px) 100vw, 33vw" />
            <h2>{s.name}</h2><p>{s.headline}</p>
          </Link>
        ))}
      </div></section>
      <CTA />
    </>
  );
}
