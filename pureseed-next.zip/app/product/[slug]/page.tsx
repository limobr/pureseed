import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import CTA from "@/components/CTA";
import ProductCard from "@/components/ProductCard";
import { meta } from "@/lib/seo";
import { products, site } from "@/lib/data";

export const dynamicParams = false;
export function generateStaticParams() { return products.map((p) => ({ slug: p.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = products.find((x) => x.slug === slug);
  if (!p) return {};
  return meta(p.name, `${p.headline}. ${p.intro[0]}`, `/product/${p.slug}`, p.image);
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = products.find((x) => x.slug === slug);
  if (!p) notFound();
  const ld = {
    "@context": "https://schema.org", "@type": "Product", name: p.name, description: p.intro.join(" "), image: p.image,
    brand: { "@type": "Brand", name: site.name }, category: "Agricultural products",
  };
  return (
    <>
      <section className="page-hero"><div className="wrap"><p className="crumb"><Link href="/shop">Products</Link></p><h1>{p.name}</h1><p className="lead">{p.headline}</p></div></section>
      <section className="sec"><div className="wrap split">
        <Image src={p.image} alt={p.name} width={520} height={520} priority sizes="(max-width:900px) 100vw, 40vw" className="pimg" />
        <div>
          {p.intro.map((t) => <p key={t}>{t}</p>)}
          <h2>Product highlights</h2>
          <ul className="ticks">{p.highlights.map((h) => <li key={h}>{h}</li>)}</ul>
          <h2>{p.blockTitle}</h2>
          {p.blockBody.map((t) => <p key={t}>{t}</p>)}
          <Link href={`/contact-us?product=${encodeURIComponent(p.name)}`} className="btn">Request a quote</Link>
        </div>
      </div></section>
      <section className="sec"><div className="wrap"><Image src={p.gallery} alt={`${p.name}: sourcing and processing`} width={1600} height={700} sizes="(max-width:1200px) 100vw, 1160px" className="banner" /></div></section>
      <section className="sec alt"><div className="wrap"><h2>Related products</h2>
        <div className="pgrid">{products.filter((x) => x.slug !== p.slug).map((x) => <ProductCard key={x.slug} p={x} />)}</div></div></section>
      <CTA />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
    </>
  );
}
