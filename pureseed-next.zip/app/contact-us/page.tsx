import ContactForm from "@/components/ContactForm";
import { meta } from "@/lib/seo";
import { site } from "@/lib/data";

export const metadata = meta("Contact Us", "Contact PureSeed for premium African agricultural products: sesame, cashew, groundnuts and honey. Request a quote for bulk or private-label supply.", "/contact-us");

export default async function Contact({ searchParams }: { searchParams: Promise<{ product?: string }> }) {
  const { product } = await searchParams;
  return (
    <>
      <section className="page-hero"><div className="wrap"><h1>Contact us</h1><p className="lead">Tell us what you need and we will reply by email.</p></div></section>
      <section className="sec"><div className="wrap split">
        <ContactForm defaultProduct={product} />
        <div>
          <h3>Email</h3><p><a href={`mailto:${site.email}`}>{site.email}</a></p>
          <h3>Phone and WhatsApp</h3><p><a href={`tel:${site.phone}`}>{site.phone}</a> · <a href={site.whatsapp} rel="noopener">WhatsApp</a></p>
          <h3>Location</h3><p>{site.address}</p>
        </div>
      </div></section>
    </>
  );
}
