import Link from "next/link";
import Image from "next/image";
import CTA from "@/components/CTA";
import { meta } from "@/lib/seo";
import { products } from "@/lib/data";

export const metadata = meta("Products", "Sesame seeds, sesame oil, cashew nuts, groundnuts and organic honey: sourced in Africa, processed and prepared for international buyers.", "/shop");

export default function Shop() {
  return (
    <>
      <section className="page-hero"><div className="wrap"><h1>Our products</h1><p className="lead">A focused portfolio of agricultural products sourced, processed, and prepared for international buyers.</p></div></section>
      <section className="sec"><div className="wrap plist">
        {products.map((p) => (
          <Link key={p.slug} href={`/product/${p.slug}`} className="prow">
            <Image src={p.image} alt={p.name} width={200} height={200} sizes="160px" />
            <div><h2>{p.name}</h2><p>{p.intro[0]}</p></div>
          </Link>
        ))}
      </div></section>
      <CTA label="Request a quote" />
    </>
  );
}
