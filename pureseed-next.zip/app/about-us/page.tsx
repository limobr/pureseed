import CTA from "@/components/CTA";
import ProductCard from "@/components/ProductCard";
import { meta } from "@/lib/seo";
import { products } from "@/lib/data";

export const metadata = meta("About Us", "PureSeed combines agricultural sourcing, processing, quality control, packaging and export coordination under one integrated supply chain.", "/about-us");

export default function About() {
  return (
    <>
      <section className="page-hero"><div className="wrap"><h1>About PureSeed</h1><p className="lead">We transform agricultural raw materials into processed, market-ready products.</p></div></section>
      <section className="sec"><div className="wrap split">
        <div>
          <h2>More than agricultural supply</h2>
          <p>PureSeed combines agricultural sourcing, processing, quality control, packaging, and export coordination under one integrated supply chain.</p>
        </div>
        <div>
          <h3>Quality &amp; consistency</h3>
          <p>We apply controlled processes and quality standards throughout our operations to deliver products that meet customer and market requirements.</p>
          <h3>Traceability &amp; control</h3>
          <p>From origin to shipment, PureSeed maintains visibility across key stages of the supply chain, supporting transparency and dependable sourcing.</p>
        </div>
      </div></section>
      <section className="sec alt"><div className="wrap">
        <h2>Turning African agriculture into global value</h2>
        <p className="measure">PureSeed goes beyond sourcing agricultural commodities. We add value through processing, preparation, packaging, and product development designed for international markets.</p>
        <ul className="ticks"><li>Flexible product solutions</li><li>Built for market needs</li><li>From raw to ready</li></ul>
      </div></section>
      <section className="sec"><div className="wrap"><h2>Our products</h2><div className="pgrid">{products.map((p) => <ProductCard key={p.slug} p={p} />)}</div></div></section>
      <CTA />
    </>
  );
}
