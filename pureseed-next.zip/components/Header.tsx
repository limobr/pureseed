import Image from "next/image";
import Link from "next/link";
import NavMenu from "./NavMenu";
import { logo, site } from "@/lib/data";

export default function Header() {
  return (
    <header className="hdr">
      <div className="bar">
        <a href={`mailto:${site.email}`}>{site.email}</a>
        <a href={`tel:${site.phone}`}>{site.phone}</a>
      </div>
      <div className="wrap hdr-main">
        <Link href="/" aria-label="PureSeed home">
          <Image src={logo} alt="PureSeed" width={154} height={48} priority style={{ height: 48, width: "auto" }} />
        </Link>
        <NavMenu />
      </div>
    </header>
  );
}
