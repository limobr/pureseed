import Link from "next/link";

export default function CTA({ title = "Ready to discuss your requirements?", label = "Request a quote" }) {
  return (
    <section className="cta">
      <div className="wrap">
        <h2>{title}</h2>
        <Link href="/contact-us" className="btn btn-light">{label}</Link>
      </div>
    </section>
  );
}
