import Image from "next/image";
import Link from "next/link";
import type { Product } from "@/lib/data";

export default function ProductCard({ p }: { p: Product }) {
  return (
    <Link href={`/product/${p.slug}`} className="pcard">
      <Image src={p.image} alt={p.name} width={320} height={320} sizes="(max-width:700px) 50vw, 20vw" />
      <span>{p.name}</span>
    </Link>
  );
}
