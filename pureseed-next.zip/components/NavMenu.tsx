"use client";
import Link from "next/link";
import { useState } from "react";
import { nav } from "@/lib/data";

export default function NavMenu() {
  const [open, setOpen] = useState(false);
  return (
    <div className="menu">
      <button className="menu-btn" aria-expanded={open} aria-controls="primary-nav" onClick={() => setOpen(!open)}>
        {open ? "Close" : "Menu"}
      </button>
      <nav id="primary-nav" aria-label="Primary" className={open ? "open" : ""} onClick={() => setOpen(false)}>
        {nav.map((n) => <Link key={n.href} href={n.href}>{n.label}</Link>)}
        <Link href="/contact-us" className="btn">Let’s Talk</Link>
      </nav>
    </div>
  );
}
