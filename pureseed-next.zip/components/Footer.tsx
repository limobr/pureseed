import Image from "next/image";
import Link from "next/link";
import { logoLight, nav, products, site } from "@/lib/data";

export default function Footer() {
  return (
    <footer className="ftr">
      <div className="wrap grid3">
        <div>
          <Image src={logoLight} alt="PureSeed" width={170} height={53} style={{ height: 53, width: "auto" }} />
          <p>{site.tagline}.</p>
        </div>
        <div>
          <h3>Contact</h3>
          <p><a href={`mailto:${site.email}`}>{site.email}</a></p>
          <p><a href={`tel:${site.phone}`}>{site.phone}</a></p>
          <p><a href={site.whatsapp} rel="noopener">WhatsApp</a></p>
          <p>{site.address}</p>
        </div>
        <div>
          <h3>Products</h3>
          {products.map((p) => <p key={p.slug}><Link href={`/product/${p.slug}`}>{p.name}</Link></p>)}
        </div>
      </div>
      <div className="wrap sub">
        <span>© {new Date().getFullYear()} PureSeed. All rights reserved.</span>
        <span>{nav.map((n) => <Link key={n.href} href={n.href}>{n.label}</Link>)}</span>
      </div>
    </footer>
  );
}
