"use client";
import { useEffect, useRef, useState } from "react";

/**
 * Fade-and-rise on scroll. Content is fully visible in the server HTML and without JS;
 * it is only hidden after hydration, and only for blocks that start below the fold.
 * Does nothing under prefers-reduced-motion. Animates once.
 */
export default function Reveal({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<"idle" | "hidden" | "shown">("idle");

  useEffect(() => {
    const el = ref.current;
    if (!el || !("IntersectionObserver" in window)) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (el.getBoundingClientRect().top < window.innerHeight * 0.9) return; // already on screen
    setState("hidden");
    const io = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setState("shown"); io.disconnect(); }
    }, { rootMargin: "0px 0px -8% 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return <div ref={ref} className={`reveal ${className}`.trim()} data-reveal={state}>{children}</div>;
}
