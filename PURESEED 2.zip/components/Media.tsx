"use client";
import Image from "next/image";
import { useState } from "react";

type Props = {
  src: string;
  alt: string;
  /** CSS aspect-ratio, e.g. "4/3". Reserves space so nothing shifts while loading. */
  ratio: string;
  sizes: string;
  /** Above-the-fold image: eager, high priority, no fade (so it never delays LCP). */
  priority?: boolean;
  /** "contain" for transparent product cut-outs, "cover" for photography. */
  fit?: "cover" | "contain";
  /** Opt-in 1.03x hover zoom. */
  zoom?: boolean;
  className?: string;
};

export default function Media({ src, alt, ratio, sizes, priority = false, fit = "cover", zoom = false, className = "" }: Props) {
  const [loaded, setLoaded] = useState(false);
  return (
    <div className={`media ${className}`.trim()} style={{ aspectRatio: ratio }} data-fit={fit} data-zoom={zoom || undefined} data-fade={priority ? undefined : ""}>
      <Image
        src={src}
        alt={alt}
        fill
        sizes={sizes}
        priority={priority}
        className={loaded ? "is-loaded" : undefined}
        onLoad={() => setLoaded(true)}
        onError={() => setLoaded(true)}
        ref={(el) => { if (el?.complete) setLoaded(true); }}
      />
    </div>
  );
}
