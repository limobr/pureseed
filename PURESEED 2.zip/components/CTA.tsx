import Link from "next/link";
import Reveal from "./Reveal";

export default function CTA({ title = "Ready to discuss your requirements?", label = "Request a quote" }) {
  return (
    <section className="cta">
      <Reveal className="wrap">
        <h2>{title}</h2>
        <Link href="/contact-us" className="btn btn-amber">{label}</Link>
      </Reveal>
    </section>
  );
}
