import Link from "next/link";
import CTA from "@/components/CTA";
import Media from "@/components/Media";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";
import Process from "@/components/Process";
import { buyers, heroImage, products, services, valueProps } from "@/lib/data";

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="wrap hero-grid">
          <div>
            <h1>Value-added agricultural products, from Africa to global markets.</h1>
            <p className="lead">PureSeed sources, processes and delivers sesame seeds, sesame oil, cashew nuts, groundnuts and organic honey, with quality control, traceability and flexible packaging for international buyers.</p>
            <div className="row">
              <Link href="/shop" className="btn">Explore our products</Link>
              <Link href="/contact-us" className="btn btn-ghost">Request an enquiry</Link>
            </div>
          </div>
          <Media src={heroImage} alt="PureSeed product range: sesame, cashew nuts, groundnuts and honey" ratio="4/5" priority sizes="(max-width:900px) 100vw, 480px" />
        </div>
      </section>

      <section className="sec">
        <Reveal className="wrap">
          <h2>Our products</h2>
          <div className="pgrid">{products.map((p) => <ProductCard key={p.slug} p={p} />)}</div>
        </Reveal>
      </section>

      <section className="sec alt">
        <Reveal className="wrap grid4">
          {valueProps.map((v) => <div key={v.h} className="vp"><h3>{v.h}</h3><p>{v.p}</p></div>)}
        </Reveal>
      </section>

      <section className="sec">
        <Reveal className="wrap">
          <div className="sec-head">
            <h2>From origin to shipment</h2>
            <p>One supply chain, managed end to end, so what you specify is what arrives.</p>
          </div>
          <Process />
        </Reveal>
      </section>

      <section className="sec alt">
        <Reveal className="wrap split">
          <div>
            <h2>From African origins to global markets</h2>
            <p>PureSeed is an integrated agricultural processor, manufacturer, and exporter delivering quality agricultural products from Africa to international markets.</p>
            <p>We manage the journey from sourcing and processing to quality control, packaging, and export preparation, giving our customers greater consistency, traceability, and confidence in every shipment.</p>
            <ul className="ticks">
              <li>Reliable global supply</li><li>Quality &amp; traceability</li><li>Bulk &amp; private label solutions</li><li>Export-ready products</li>
            </ul>
            <Link href="/about-us" className="btn btn-ghost">More about us</Link>
          </div>
          <div className="svc-list">
            {services.map((s) => (
              <Link key={s.slug} href={`/service/${s.slug}`}><strong>{s.name}</strong><span>{s.headline}</span></Link>
            ))}
          </div>
        </Reveal>
      </section>

      <section className="sec">
        <Reveal className="wrap">
          <div className="sec-head">
            <h2>Who we supply</h2>
            <p>We work with businesses that need dependable volumes and consistent specifications.</p>
          </div>
          <div className="cards4">{buyers.map((b) => <div key={b.h} className="info"><h3>{b.h}</h3><p>{b.p}</p></div>)}</div>
        </Reveal>
      </section>

      <CTA title="Your product. Your brand. Our production." label="Contact us today" />
    </>
  );
}
